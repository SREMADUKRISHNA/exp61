import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import rainbowCake from "@/assets/rainbow-cake.jpg";
import chocolateCake from "@/assets/chocolate-cake.jpg";
import redVelvetCake from "@/assets/red-velvet-cake.jpg";
import blackForestCake from "@/assets/black-forest-cake.jpg";

interface Cake {
  id: string;
  name: string;
  price: number;
  image: string;
}

const cakes: Cake[] = [
  { id: "rainbow", name: "Rainbow Cake", price: 300, image: rainbowCake },
  { id: "chocolate", name: "Chocolate Cake", price: 200, image: chocolateCake },
  { id: "redVelvet", name: "Red Velvet Cake", price: 250, image: redVelvetCake },
  { id: "blackForest", name: "Black Forest Cake", price: 350, image: blackForestCake },
];

const Index = () => {
  const [quantities, setQuantities] = useState<Record<string, number>>({
    rainbow: 0,
    chocolate: 0,
    redVelvet: 0,
    blackForest: 0,
  });
  const [totalPrice, setTotalPrice] = useState<number | null>(null);

  const handleQuantityChange = (id: string, value: string) => {
    const numValue = parseInt(value) || 0;
    setQuantities((prev) => ({ ...prev, [id]: numValue }));
  };

  const calculateTotal = () => {
    const total = cakes.reduce((sum, cake) => {
      return sum + cake.price * (quantities[cake.id] || 0);
    }, 0);
    setTotalPrice(total);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Red Banner */}
      <header className="w-full py-8 bg-[hsl(var(--banner-bg))] shadow-lg">
        <h1 className="text-5xl font-bold text-white text-center tracking-wide">
          CAKE SHOP
        </h1>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Cake Display Section */}
        <section className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {cakes.map((cake) => (
              <div
                key={cake.id}
                className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-hover transition-shadow duration-300"
              >
                <div className="overflow-hidden">
                  <img
                    src={cake.image}
                    alt={cake.name}
                    className="w-full h-64 object-cover hover-zoom"
                  />
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-semibold mb-2 text-card-foreground">
                    {cake.name}
                  </h3>
                  <p className="text-2xl font-bold text-primary">
                    Rs. {cake.price}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Order Form Section */}
        <section className="max-w-2xl mx-auto">
          <Card className="shadow-soft">
            <CardHeader className="bg-muted/50">
              <CardTitle className="text-3xl text-center font-bold">
                Order Cake
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="space-y-6">
                {cakes.map((cake) => (
                  <div key={cake.id} className="flex items-center justify-between gap-4">
                    <label
                      htmlFor={cake.id}
                      className="text-lg font-medium flex-1"
                    >
                      {cake.name}
                    </label>
                    <Input
                      id={cake.id}
                      type="number"
                      min="0"
                      value={quantities[cake.id]}
                      onChange={(e) => handleQuantityChange(cake.id, e.target.value)}
                      placeholder="Quantity"
                      className="w-32 text-center"
                    />
                  </div>
                ))}
              </div>

              <Button
                onClick={calculateTotal}
                className="w-full mt-8 text-lg py-6 bg-[hsl(var(--order-button))] hover:bg-[hsl(var(--order-button))]/90 text-white font-semibold transition-all duration-300"
                size="lg"
              >
                Place Order
              </Button>

              {totalPrice !== null && (
                <div className="mt-8 p-6 bg-[hsl(var(--total-bg))] rounded-xl text-center animate-fade-in">
                  <p className="text-2xl font-bold text-white">
                    Total Price: Rs. {totalPrice}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
};

export default Index;
